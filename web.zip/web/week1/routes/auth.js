const express = require('express');
const router = express.Router();
const passport = require('passport');
const User = require('../models/user');

// 회원가입 페이지 렌더링
router.get('/register', (req, res) => {
  res.render('register');
});

// 회원가입 처리
router.post('/register', (req, res) => {
  User.register(
    new User({ username: req.body.username }),
    req.body.password,
    (err, user) => {
      if (err) {
        console.log(err);
        return res.render('register');
      }

      passport.authenticate('local')(req, res, () => {
        res.redirect('/profile');
      });
    }
  );
});

// 로그인 페이지 렌더링
router.get('/login', (req, res)
