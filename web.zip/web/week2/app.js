const express = require('express');
const bcrypt = require('bcrypt');
const mongoose = require('mongoose');
const fileUpload = require('express-fileupload');

// MongoDB 연결
mongoose.connect('mongodb://localhost/cat_sns', { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.log(err));

// 스키마 정의
const UserSchema = new mongoose.Schema({
  username: { type: String, unique: true },
  password: String
});
const User = mongoose.model('User', UserSchema);

const PostSchema = new mongoose.Schema({
  content: String,
  imageUrl: String,
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }
});
const Post = mongoose.model('Post', PostSchema);

// Express 앱 설정
const app = express();
app.use(express.json());
app.use(fileUpload());

// 회원가입
app.post('/signup', async (req, res) => {
  const { username, password } = req.body;
  const hashedPassword = await bcrypt.hash(password, 10);

  try {0
    const user = new User({ username, password: hashedPassword });
    await user.save();
    res.status(200).send('Signup successful!');
  } catch (err) {
    res.status(500).send('Error: Unable to signup');
  }
});

// 로그인
app.post('/login', async (req, res) => {
  const { username, password } = req.body;

  try {
    const user = await User.findOne({ username });
    if (!user) {
      return res.status(400).send('Invalid username or password');
    }

    const passwordMatch = await bcrypt.compare(password, user.password);
    if (!passwordMatch) {
      return res.status(400).send('Invalid username or password');
    }

    res.status(200).send('Login successful!');
  } catch (err) {
    res.status(500).send('Error: Unable to login');
  }
});

// 글 작성
app.post('/post', async (req, res) => {
  const { content, userId } = req.body;
  const image = req.files.image;

  try {
    // 이미지 업로드
    const imagePath = `uploads/${Date.now()}_${image.name}`;
    await image.mv(imagePath);

    // 게시물 생성
    const post = new Post({ content, imageUrl: imagePath, userId });
    await post.save();

    res.status(200).send('Post created!');
  } catch (err) {
    res.status(500).send('Error: Unable to create post');
  }
});

// 서버 실행
app.listen(3000, () => {
  console.log('Server started on port 3000');
});